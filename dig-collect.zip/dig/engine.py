"""
逐層掘進 · 像素圖產生器（引擎）
--------------------------------
只負責「畫剪影 → 自動上四色 → 輸出 ASCII / PNG」。
內容資料在 content.py。

四色字元：
  '.' 透明   '#' 身體   '+' 陰影   '*' 反光
剪影只需要畫 '#'，陰影與反光由 shade() 自動推導。
"""
import math, random

T, B, S, H = '.', '#', '+', '*'


# ---------- grid ----------
def grid(w, h):
    return [[T] * w for _ in range(h)]


def put(g, x, y, c=B):
    if 0 <= y < len(g) and 0 <= x < len(g[0]):
        g[y][x] = c


def get(g, x, y):
    if 0 <= y < len(g) and 0 <= x < len(g[0]):
        return g[y][x]
    return T


# ---------- primitives ----------
def ellipse(g, cx, cy, rx, ry, c=B):
    for y in range(len(g)):
        for x in range(len(g[0])):
            if rx <= 0 or ry <= 0:
                continue
            if ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 <= 1.0:
                put(g, x, y, c)


def rect(g, x0, y0, x1, y1, c=B):
    for y in range(int(y0), int(y1) + 1):
        for x in range(int(x0), int(x1) + 1):
            put(g, x, y, c)


def line(g, x0, y0, x1, y1, c=B, thick=1):
    n = int(max(abs(x1 - x0), abs(y1 - y0))) + 1
    for i in range(n + 1):
        t = i / max(n, 1)
        x = x0 + (x1 - x0) * t
        y = y0 + (y1 - y0) * t
        for dx in range(thick):
            for dy in range(thick):
                put(g, int(round(x)) + dx, int(round(y)) + dy, c)


def poly(g, pts, c=B):
    ys = [p[1] for p in pts]
    for y in range(int(min(ys)), int(max(ys)) + 1):
        xs = []
        n = len(pts)
        for i in range(n):
            x0, y0 = pts[i]
            x1, y1 = pts[(i + 1) % n]
            if y0 == y1:
                continue
            if min(y0, y1) <= y < max(y0, y1):
                xs.append(x0 + (y - y0) * (x1 - x0) / (y1 - y0))
        xs.sort()
        for i in range(0, len(xs) - 1, 2):
            for x in range(int(math.floor(xs[i])), int(math.ceil(xs[i + 1])) + 1):
                put(g, x, y, c)


def blob(g, cx, cy, r, rng, wob=0.38, lobes=None, c=B):
    """不規則團塊：極座標半徑加噪聲。礦物碎屑的主力。"""
    lobes = lobes or rng.choice([3, 4, 5, 6])
    phase = [rng.uniform(0, math.tau) for _ in range(3)]
    for y in range(len(g)):
        for x in range(len(g[0])):
            dx, dy = x - cx, y - cy
            d = math.hypot(dx, dy)
            if d > r * 1.9:
                continue
            a = math.atan2(dy, dx)
            rr = r * (1 + wob * 0.5 * math.sin(lobes * a + phase[0])
                        + wob * 0.3 * math.sin((lobes + 3) * a + phase[1])
                        + wob * 0.2 * math.sin((lobes * 2 + 1) * a + phase[2]))
            if d <= rr:
                put(g, x, y, c)


def facet(g, cx, cy, r, rng, sides=6, squash=1.0, rot=0.0, c=B):
    """多面體：晶體用。"""
    pts = []
    for i in range(sides):
        a = rot + i * math.tau / sides
        jitter = rng.uniform(0.82, 1.14)
        pts.append((cx + math.cos(a) * r * jitter,
                    cy + math.sin(a) * r * jitter * squash))
    poly(g, pts, c)


def carve(g, fn):
    """把 fn 畫出來的地方挖空（做中空、孔洞）。"""
    tmp = grid(len(g[0]), len(g))
    fn(tmp)
    for y in range(len(g)):
        for x in range(len(g[0])):
            if tmp[y][x] != T:
                g[y][x] = T


def holes(g, rng, n=6, r=1):
    """在既有形體上打隨機小孔。"""
    cells = [(x, y) for y in range(len(g)) for x in range(len(g[0])) if g[y][x] != T]
    if not cells:
        return
    rng.shuffle(cells)
    for (x, y) in cells[:n]:
        for dy in range(-r, r + 1):
            for dx in range(-r, r + 1):
                if dx * dx + dy * dy <= r * r:
                    if get(g, x + dx, y + dy) != T:
                        put(g, x + dx, y + dy, T)


def jag(g, rng, amount=0.35, side='all'):
    """啃掉邊緣，讓輪廓變碎。"""
    edge = []
    for y in range(len(g)):
        for x in range(len(g[0])):
            if g[y][x] == T:
                continue
            if (get(g, x - 1, y) == T or get(g, x + 1, y) == T
                    or get(g, x, y - 1) == T or get(g, x, y + 1) == T):
                if side == 'top' and y > len(g) // 2:
                    continue
                if side == 'bottom' and y < len(g) // 2:
                    continue
                edge.append((x, y))
    for (x, y) in edge:
        if rng.random() < amount:
            put(g, x, y, T)


def clean(g, min_run=1):
    """清掉孤立像素（1px 雜點在 16px 畫布上會很髒）。"""
    for _ in range(2):
        drop = []
        for y in range(len(g)):
            for x in range(len(g[0])):
                if g[y][x] == T:
                    continue
                n = sum(1 for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))
                        if get(g, x + dx, y + dy) != T)
                if n <= min_run - 1:
                    drop.append((x, y))
        for (x, y) in drop:
            put(g, x, y, T)


# ---------- shading ----------
def shade(g):
    """
    半自動四色。光從左上。

    畫稿字元
      '.' 空
      '#' 身體
      '%' 我手畫的「暗」——刻痕、裂縫、凹陷、紋路、孔。輸出成陰影色。
      '*' 我手畫的「亮」——發光、水珠、反射面。少用，只用在真的該亮的地方。

    自動補的只有輪廓光影：
      身體的上緣／左緣 → 反光 '*'
      身體的下緣／右緣 → 陰影 '+'
    這樣物件會有立體感，而手畫的暗紋是凹進去的，不會被誤讀成洞。
    """
    h, w = len(g), len(g[0])
    out = [row[:] for row in g]

    def solid(x, y):
        return get(g, x, y) != T

    def n8(x, y):
        return sum(1 for dx in (-1, 0, 1) for dy in (-1, 0, 1)
                   if not (dx == 0 and dy == 0) and solid(x + dx, y + dy))

    for y in range(h):
        for x in range(w):
            c = g[y][x]
            if c == T:
                continue
            if c == '%':
                out[y][x] = S
                continue
            if c == H:
                continue
            if n8(x, y) < 3:            # 一兩格寬的細部位維持本色
                continue
            up = not solid(x, y - 1)
            left = not solid(x - 1, y)
            down = not solid(x, y + 1)
            right = not solid(x + 1, y)
            if down or right:
                out[y][x] = S
            elif up and left:        # 只有真正的左上角才打亮，避免整圈描邊
                out[y][x] = H
            elif up and n8(x, y) >= 6:
                out[y][x] = H
    return out


# ---------- output ----------
def to_ascii(g):
    return [''.join(row) for row in g]


def coverage(g):
    tot = len(g) * len(g[0])
    n = sum(1 for row in g for c in row if c != T)
    return n / tot


PAL = {
    '荒原': {'body': '#8A7448', 'shadow': '#4A3B21', 'hi': '#C8B173', 'bg': '#201B12'},
    '迴廊': {'body': '#4C86A8', 'shadow': '#1F4257', 'hi': '#A8DCF0', 'bg': '#0E1E28'},
    '迷宮': {'body': '#6A5A8C', 'shadow': '#2E2545', 'hi': '#B9A8DC', 'bg': '#15111F'},
    '深淵': {'body': '#B85030', 'shadow': '#4A1C10', 'hi': '#F0B173', 'bg': '#1E0F0A'},
}


def to_png(g, path, region='荒原', scale=8, bg=True):
    from PIL import Image
    p = PAL[region]
    h, w = len(g), len(g[0])
    img = Image.new('RGB', (w * scale, h * scale),
                    _hex(p['bg']) if bg else (0, 0, 0))
    px = img.load()
    cmap = {B: _hex(p['body']), S: _hex(p['shadow']), H: _hex(p['hi'])}
    for y in range(h):
        for x in range(w):
            c = g[y][x]
            if c == T:
                continue
            col = cmap[c]
            for sy in range(scale):
                for sx in range(scale):
                    px[x * scale + sx, y * scale + sy] = col
    img.save(path)
    return img


def _hex(s):
    s = s.lstrip('#')
    return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))


def contact_sheet(items, path, cols=12, scale=5, pad=3, label=False):
    """items: list of (grid, region, name)"""
    from PIL import Image, ImageDraw
    if not items:
        return
    cw = max(len(g[0]) for g, _, _ in items)
    ch = max(len(g) for g, _, _ in items)
    cellw, cellh = cw * scale + pad * 2, ch * scale + pad * 2 + (10 if label else 0)
    rows = (len(items) + cols - 1) // cols
    img = Image.new('RGB', (cols * cellw, rows * cellh), (14, 16, 20))
    d = ImageDraw.Draw(img)
    for i, (g, region, name) in enumerate(items):
        r, c = divmod(i, cols)
        ox, oy = c * cellw + pad, r * cellh + pad
        p = PAL[region]
        d.rectangle([c * cellw, r * cellh, (c + 1) * cellw - 1, (r + 1) * cellh - 1],
                    fill=_hex(p['bg']))
        cmap = {B: _hex(p['body']), S: _hex(p['shadow']), H: _hex(p['hi'])}
        for y in range(len(g)):
            for x in range(len(g[0])):
                ch_ = g[y][x]
                if ch_ == T:
                    continue
                d.rectangle([ox + x * scale, oy + y * scale,
                             ox + (x + 1) * scale - 1, oy + (y + 1) * scale - 1],
                            fill=cmap[ch_])
    img.save(path)
    return img
