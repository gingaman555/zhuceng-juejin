# -*- coding: utf-8 -*-
"""手繪版：組裝 172 張 + 內容 JSON + 檢查表"""
import json, os, importlib, sys
from engine import shade, to_ascii, coverage, contact_sheet, T
from content import DEBRIS, TROPHIES, CREATURES

OUT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, OUT)
REGIONS = ['荒原', '迴廊', '迷宮', '深淵']
FULL = {'荒原': '微光荒原', '迴廊': '水晶迴廊', '迷宮': '迴聲迷宮', '深淵': '熔火深淵'}

DEB_ART = {r: importlib.import_module(f'art_{r}').ART for r in REGIONS}
TRO_ART = importlib.import_module('art_trophy').ART
CRE_ART = importlib.import_module('art_creature').ART


def parse(s, w, h):
    rows = [r for r in s.strip('\n').split('\n')]
    g = [list(r.ljust(w, '.')[:w]) for r in rows]
    while len(g) < h:
        g.append(['.'] * w)
    return g[:h]


def run():
    errs, deb, tro, cre = [], [], [], []
    d_sheet, t_sheet, c_sheet = [], [], []

    for region in REGIONS:
        art = DEB_ART[region]
        for rarity in ['常見', '少見', '罕見']:
            for (name, line, fam, existing) in DEBRIS[region][rarity]:
                if name not in art:
                    errs.append(f'缺圖 掉落物 {region}/{name}')
                    continue
                g = parse(art[name], 16, 16)
                sg = shade(g)
                deb.append({'id': f'D-{region}-{name}', 'region': FULL[region],
                            'rarity': rarity, 'name': name, 'line': line,
                            'existing': existing, 'w': 16, 'h': 16,
                            'px': to_ascii(sg), 'coverage': round(coverage(sg), 3)})
                d_sheet.append((sg, region, name))
        for (name, line, words, fam, existing) in TROPHIES[region]:
            if name not in TRO_ART:
                errs.append(f'缺圖 戰利品 {region}/{name}')
                continue
            g = parse(TRO_ART[name], 16, 16)
            sg = shade(g)
            tro.append({'id': f'T-{region}-{name}', 'region': FULL[region],
                        'name': name, 'line': line, 'words': words,
                        'existing': existing, 'w': 16, 'h': 16,
                        'px': to_ascii(sg), 'coverage': round(coverage(sg), 3)})
            t_sheet.append((sg, region, name))
        for (name, mat, act, suf, trait, look) in CREATURES[region]:
            if name not in CRE_ART:
                errs.append(f'缺圖 生物 {region}/{name}')
                continue
            g = parse(CRE_ART[name], 24, 16)
            sg = shade(g)
            cre.append({'id': f'C-{region}-{name}', 'region': FULL[region],
                        'name': name, 'material': mat, 'action': act,
                        'suffix': suf, 'trait': trait, 'look': look,
                        'w': 24, 'h': 16, 'px': to_ascii(sg),
                        'coverage': round(coverage(sg), 3)})
            c_sheet.append((sg, region, name))

    contact_sheet(d_sheet, os.path.join(OUT, 'sheet_debris.png'), cols=15, scale=6)
    contact_sheet(t_sheet, os.path.join(OUT, 'sheet_trophies.png'), cols=6, scale=9)
    contact_sheet(c_sheet, os.path.join(OUT, 'sheet_creatures.png'), cols=10, scale=6)

    pack = {'_meta': {'name': '逐層掘進 · 收集內容包', 'version': '2.0',
                      'date': '2026-08-30',
                      'charset': {'.': '透明', '#': '身體', '+': '陰影', '*': '反光'},
                      'sizes': {'debris': '16x16', 'trophies': '16x16', 'creatures': '24x16'},
                      'counts': {'debris': len(deb), 'trophies': len(tro), 'creatures': len(cre)}},
            'debris': deb, 'trophies': tro, 'creatures': cre}
    with open(os.path.join(OUT, 'collect-pack.json'), 'w', encoding='utf-8') as f:
        json.dump(pack, f, ensure_ascii=False, indent=1)

    print(f'掉落物 {len(deb)}　戰利品 {len(tro)}　生物 {len(cre)}　合計 {len(deb)+len(tro)+len(cre)}')
    for label, arr in (('掉落物', deb), ('戰利品', tro), ('生物', cre)):
        cov = [x['coverage'] for x in arr]
        sig = ['\n'.join(x['px']) for x in arr]
        print(f'  {label}：佔格 {min(cov):.2f}–{max(cov):.2f}（平均 {sum(cov)/len(cov):.2f}）　重複 {len(sig)-len(set(sig))}')
    # 稀有度分佈
    from collections import Counter
    print('  稀有度', dict(Counter(x['rarity'] for x in deb)))
    for r in REGIONS:
        c = Counter(x['rarity'] for x in deb if x['region'] == FULL[r])
        print(f'    {FULL[r]}：常見{c["常見"]} 少見{c["少見"]} 罕見{c["罕見"]}')
    if errs:
        print('\n!! 問題：')
        for e in errs:
            print('  ', e)
    else:
        print('\n全部到齊，無缺圖。')


if __name__ == '__main__':
    run()
